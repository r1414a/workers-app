// src/app/(onboarding)/permissions.tsx

import { router } from "expo-router";
import { ActivityIndicator, Pressable, Text, View } from "react-native";

import { Bell, Camera, MapPin } from "lucide-react-native";

import { usePermissions } from "@/hooks/use-permissions";

export default function PermissionsScreen() {
  const { loading, perms, allGranted, requestAll } = usePermissions();

  return (
    <View className="flex-1 bg-white p-6">
      <Text className="mt-10 text-3xl font-bold">Permissions</Text>

      <Text className="mt-2 text-gray-500">
        We need these permissions to verify attendance and site presence.
      </Text>

      <View className="mt-10 gap-4">
        <PermissionCard
          icon={<MapPin size={24} />}
          title="Location"
          granted={perms.foregroundLocation}
        />

        <PermissionCard
          icon={<MapPin size={24} />}
          title="Background Location"
          granted={perms.backgroundLocation}
        />

        <PermissionCard
          icon={<Camera size={24} />}
          title="Camera"
          granted={perms.camera}
        />

        <PermissionCard
          icon={<Bell size={24} />}
          title="Notifications"
          granted={perms.notifications}
        />
      </View>

      {!allGranted && (
        <Pressable
          onPress={requestAll}
          className="mt-10 h-14 items-center justify-center rounded-xl bg-blue-600"
        >
          {loading ? (
            <ActivityIndicator color="white" />
          ) : (
            <Text className="font-semibold text-white">Grant Permissions</Text>
          )}
        </Pressable>
      )}

      {allGranted && (
        <Pressable
          className="mt-10 h-14 items-center justify-center rounded-xl bg-green-600"
          onPress={() => router.push("/(onboarding)/personal-info")}
        >
          <Text className="font-semibold text-white">Continue</Text>
        </Pressable>
      )}
    </View>
  );
}

function PermissionCard({
  title,
  granted,
  icon,
}: {
  title: string;
  granted: boolean;
  icon: React.ReactNode;
}) {
  return (
    <View className="flex-row items-center justify-between rounded-xl border p-4">
      <View className="flex-row items-center gap-3">
        {icon}
        <Text>{title}</Text>
      </View>

      <View
        className={`h-3 w-3 rounded-full ${
          granted ? "bg-green-500" : "bg-red-500"
        }`}
      />
    </View>
  );
}
