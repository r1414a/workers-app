/**
 * app/(tabs)/index.tsx — Home Dashboard
 * Construction Workforce Attendance App
 */

import { router } from "expo-router";
import React, { useCallback } from "react";
import {
  RefreshControl,
  ScrollView,
  StatusBar,
  Text,
  TouchableOpacity,
  View
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

// ─── Types ────────────────────────────────────────────────────────────────────
type AttendanceStatus = "checked_in" | "checked_out" | "absent";

interface WorkerProfile {
  fullName: string;
  employeeId: string;
  siteName: string;
  siteDistanceMeters: number;
}

interface AttendanceSummary {
  presentDays: number;
  absentDays: number;
  lateDays: number;
  totalWorkingDays: number;
}

interface TodayRecord {
  status: AttendanceStatus;
  checkInTime: string | null;
  checkOutTime: string | null;
  hoursWorked: number | null;
}

// ─── Mock data (replace with Redux selectors) ─────────────────────────────────
const MOCK_WORKER: WorkerProfile = {
  fullName: "Rajesh Kumar",
  employeeId: "EMP-2847",
  siteName: "Oberoi Realty — Tower C",
  siteDistanceMeters: 142,
};

const MOCK_TODAY: TodayRecord = {
  status: "checked_in",
  checkInTime: "08:47 AM",
  checkOutTime: null,
  hoursWorked: 3.5,
};

const MOCK_SUMMARY: AttendanceSummary = {
  presentDays: 18,
  absentDays: 1,
  lateDays: 2,
  totalWorkingDays: 21,
};

// ─── Helpers ──────────────────────────────────────────────────────────────────
function getGreeting(): string {
  const h = new Date().getHours();
  if (h < 12) return "Good morning";
  if (h < 17) return "Good afternoon";
  return "Good evening";
}

function formatDistance(meters: number): string {
  if (meters < 1000) return `${meters} m away`;
  return `${(meters / 1000).toFixed(1)} km away`;
}

function formatHours(h: number): string {
  const hrs = Math.floor(h);
  const mins = Math.round((h - hrs) * 60);
  return `${hrs}h ${mins}m`;
}

function getInitials(name: string): string {
  return name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);
}

// ─── Sub-components ───────────────────────────────────────────────────────────

interface StatusConfig {
  label: string;
  color: string;
  bg: string;
  dotColor: string;
  canCheckIn: boolean;
  canCheckOut: boolean;
}

function getStatusConfig(status: AttendanceStatus): StatusConfig {
  switch (status) {
    case "checked_in":
      return {
        label: "Checked in",
        color: "#16A34A",
        bg: "#F0FDF4",
        dotColor: "#22C55E",
        canCheckIn: false,
        canCheckOut: true,
      };
    case "checked_out":
      return {
        label: "Checked out",
        color: "#2563EB",
        bg: "#EFF6FF",
        dotColor: "#3B82F6",
        canCheckIn: false,
        canCheckOut: false,
      };
    case "absent":
      return {
        label: "Not checked in",
        color: "#DC2626",
        bg: "#FEF2F2",
        dotColor: "#EF4444",
        canCheckIn: true,
        canCheckOut: false,
      };
  }
}

// Status card
function AttendanceStatusCard({ record }: { record: TodayRecord }) {
  const cfg = getStatusConfig(record.status);
  return (
    <View
      style={{
        backgroundColor: cfg.bg,
        borderRadius: 16,
        padding: 20,
        marginBottom: 12,
        borderWidth: 1,
        borderColor: cfg.color + "22",
      }}
    >
      <View
        style={{ flexDirection: "row", alignItems: "center", marginBottom: 14 }}
      >
        {/* Pulsing dot */}
        <View
          style={{
            width: 10,
            height: 10,
            borderRadius: 5,
            backgroundColor: cfg.dotColor,
            marginRight: 8,
          }}
        />
        <Text style={{ fontSize: 13, color: cfg.color, fontWeight: "600" }}>
          {cfg.label}
        </Text>
        <Text style={{ marginLeft: "auto", fontSize: 12, color: "#6B7280" }}>
          Today
        </Text>
      </View>

      <View style={{ flexDirection: "row", gap: 24 }}>
        {record.checkInTime && (
          <View>
            <Text style={{ fontSize: 11, color: "#9CA3AF", marginBottom: 2 }}>
              Check-in
            </Text>
            <Text style={{ fontSize: 20, fontWeight: "700", color: "#111827" }}>
              {record.checkInTime}
            </Text>
          </View>
        )}
        {record.checkOutTime && (
          <View>
            <Text style={{ fontSize: 11, color: "#9CA3AF", marginBottom: 2 }}>
              Check-out
            </Text>
            <Text style={{ fontSize: 20, fontWeight: "700", color: "#111827" }}>
              {record.checkOutTime}
            </Text>
          </View>
        )}
        {record.hoursWorked !== null && (
          <View style={{ marginLeft: "auto" }}>
            <Text style={{ fontSize: 11, color: "#9CA3AF", marginBottom: 2 }}>
              Hours today
            </Text>
            <Text style={{ fontSize: 20, fontWeight: "700", color: "#111827" }}>
              {formatHours(record.hoursWorked)}
            </Text>
          </View>
        )}
      </View>
    </View>
  );
}

// Site card
function SiteCard({ worker }: { worker: WorkerProfile }) {
  const onSite = worker.siteDistanceMeters < 200;
  return (
    <View
      style={{
        backgroundColor: "#FFFFFF",
        borderRadius: 16,
        padding: 18,
        marginBottom: 12,
        borderWidth: 1,
        borderColor: "#F3F4F6",
        shadowColor: "#000",
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.05,
        shadowRadius: 4,
        elevation: 2,
      }}
    >
      <View style={{ flexDirection: "row", alignItems: "flex-start" }}>
        {/* Site icon */}
        <View
          style={{
            width: 44,
            height: 44,
            borderRadius: 12,
            backgroundColor: "#F59E0B" + "18",
            alignItems: "center",
            justifyContent: "center",
            marginRight: 14,
          }}
        >
          <Text style={{ fontSize: 22 }}>🏗️</Text>
        </View>
        <View style={{ flex: 1 }}>
          <Text style={{ fontSize: 11, color: "#9CA3AF", marginBottom: 3 }}>
            Assigned site
          </Text>
          <Text
            style={{
              fontSize: 15,
              fontWeight: "600",
              color: "#111827",
              marginBottom: 4,
            }}
            numberOfLines={1}
          >
            {worker.siteName}
          </Text>
          <View style={{ flexDirection: "row", alignItems: "center" }}>
            <View
              style={{
                width: 6,
                height: 6,
                borderRadius: 3,
                backgroundColor: onSite ? "#22C55E" : "#F59E0B",
                marginRight: 6,
              }}
            />
            <Text
              style={{
                fontSize: 12,
                color: onSite ? "#16A34A" : "#D97706",
                fontWeight: "500",
              }}
            >
              {onSite
                ? "You are on site"
                : formatDistance(worker.siteDistanceMeters)}
            </Text>
          </View>
        </View>
      </View>
    </View>
  );
}

// Summary KPI row
function SummaryRow({ summary }: { summary: AttendanceSummary }) {
  const pct = Math.round(
    (summary.presentDays / summary.totalWorkingDays) * 100,
  );
  const stats = [
    {
      label: "Present",
      value: summary.presentDays,
      color: "#16A34A",
      bg: "#F0FDF4",
    },
    {
      label: "Absent",
      value: summary.absentDays,
      color: "#DC2626",
      bg: "#FEF2F2",
    },
    { label: "Late", value: summary.lateDays, color: "#D97706", bg: "#FFFBEB" },
  ];
  return (
    <View style={{ marginBottom: 12 }}>
      <View
        style={{ flexDirection: "row", alignItems: "center", marginBottom: 10 }}
      >
        <Text
          style={{ fontSize: 14, fontWeight: "600", color: "#111827", flex: 1 }}
        >
          This month
        </Text>
        <Text style={{ fontSize: 13, color: "#6B7280" }}>
          {pct}% attendance
        </Text>
      </View>
      {/* Progress bar */}
      <View
        style={{
          height: 6,
          backgroundColor: "#F3F4F6",
          borderRadius: 3,
          marginBottom: 14,
          overflow: "hidden",
        }}
      >
        <View
          style={{
            height: 6,
            width: `${pct}%`,
            backgroundColor:
              pct >= 90 ? "#22C55E" : pct >= 75 ? "#F59E0B" : "#EF4444",
            borderRadius: 3,
          }}
        />
      </View>
      <View style={{ flexDirection: "row", gap: 10 }}>
        {stats.map((s) => (
          <View
            key={s.label}
            style={{
              flex: 1,
              backgroundColor: s.bg,
              borderRadius: 12,
              padding: 14,
              alignItems: "center",
            }}
          >
            <Text style={{ fontSize: 26, fontWeight: "700", color: s.color }}>
              {s.value}
            </Text>
            <Text style={{ fontSize: 11, color: s.color + "AA", marginTop: 2 }}>
              {s.label}
            </Text>
          </View>
        ))}
      </View>
    </View>
  );
}

// Quick action button
function QuickAction({
  icon,
  label,
  sublabel,
  onPress,
  variant = "default",
  disabled = false,
}: {
  icon: string;
  label: string;
  sublabel?: string;
  onPress: () => void;
  variant?: "primary" | "danger" | "default";
  disabled?: boolean;
}) {
  const bgMap = {
    primary: "#1D4ED8",
    danger: "#DC2626",
    default: "#FFFFFF",
  };
  const textMap = {
    primary: "#FFFFFF",
    danger: "#FFFFFF",
    default: "#111827",
  };
  const bg = disabled ? "#F3F4F6" : bgMap[variant];
  const textColor = disabled ? "#9CA3AF" : textMap[variant];

  return (
    <TouchableOpacity
      onPress={onPress}
      disabled={disabled}
      activeOpacity={0.75}
      style={{
        flex: 1,
        backgroundColor: bg,
        borderRadius: 16,
        padding: 18,
        alignItems: "center",
        borderWidth: variant === "default" ? 1 : 0,
        borderColor: "#F3F4F6",
        shadowColor: variant !== "default" ? bg : "#000",
        shadowOffset: { width: 0, height: variant !== "default" ? 4 : 1 },
        shadowOpacity: variant !== "default" ? 0.25 : 0.05,
        shadowRadius: variant !== "default" ? 10 : 4,
        elevation: variant !== "default" ? 4 : 2,
        opacity: disabled ? 0.5 : 1,
      }}
    >
      <Text style={{ fontSize: 28, marginBottom: 8 }}>{icon}</Text>
      <Text style={{ fontSize: 14, fontWeight: "600", color: textColor }}>
        {label}
      </Text>
      {sublabel && (
        <Text
          style={{
            fontSize: 11,
            color: variant !== "default" ? "#FFFFFF88" : "#9CA3AF",
            marginTop: 3,
          }}
        >
          {sublabel}
        </Text>
      )}
    </TouchableOpacity>
  );
}

// Sync indicator
function SyncBadge({ pendingCount }: { pendingCount: number }) {
  if (pendingCount === 0) return null;
  return (
    <TouchableOpacity
      style={{
        flexDirection: "row",
        alignItems: "center",
        backgroundColor: "#FEF3C7",
        borderRadius: 20,
        paddingHorizontal: 12,
        paddingVertical: 6,
        marginBottom: 16,
        alignSelf: "flex-start",
      }}
    >
      <Text style={{ fontSize: 12, marginRight: 4 }}>⏳</Text>
      <Text style={{ fontSize: 12, color: "#92400E", fontWeight: "500" }}>
        {pendingCount} record{pendingCount > 1 ? "s" : ""} pending sync
      </Text>
    </TouchableOpacity>
  );
}

// ─── Main Screen ──────────────────────────────────────────────────────────────
export default function HomeDashboard() {
  const insets = useSafeAreaInsets();
  const [refreshing, setRefreshing] = React.useState(false);
  const [pendingSync] = React.useState(0);

  // Replace with actual Redux selectors:
  const worker = MOCK_WORKER;
  const today = MOCK_TODAY;
  const summary = MOCK_SUMMARY;
  const statusConfig = getStatusConfig(today.status);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    // dispatch(fetchTodayAttendance());
    await new Promise((r) => setTimeout(r, 1200));
    setRefreshing(false);
  }, []);

  const handleCheckIn = () => router.push("/check-in");
  const handleCheckOut = () => router.push("/check-out");

  return (
    <View style={{ flex: 1, backgroundColor: "#F9FAFB" }}>
      <StatusBar barStyle="dark-content" backgroundColor="#F9FAFB" />

      {/* Header */}
      <View
        style={{
          paddingTop: insets.top + 12,
          paddingHorizontal: 20,
          paddingBottom: 16,
          backgroundColor: "#FFFFFF",
          borderBottomWidth: 1,
          borderBottomColor: "#F3F4F6",
        }}
      >
        <View style={{ flexDirection: "row", alignItems: "center" }}>
          <View style={{ flex: 1 }}>
            <Text style={{ fontSize: 13, color: "#9CA3AF", marginBottom: 2 }}>
              {getGreeting()}
            </Text>
            <Text style={{ fontSize: 20, fontWeight: "700", color: "#111827" }}>
              {worker.fullName.split(" ")[0]} 👋
            </Text>
          </View>
          {/* Avatar */}
          <TouchableOpacity
            onPress={() => router.push("/(tabs)/profile")}
            style={{
              width: 42,
              height: 42,
              borderRadius: 21,
              backgroundColor: "#1D4ED8",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Text style={{ color: "#FFFFFF", fontWeight: "700", fontSize: 15 }}>
              {getInitials(worker.fullName)}
            </Text>
          </TouchableOpacity>
        </View>

        {/* Employee ID pill */}
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            marginTop: 8,
          }}
        >
          <View
            style={{
              backgroundColor: "#EFF6FF",
              borderRadius: 20,
              paddingHorizontal: 10,
              paddingVertical: 4,
              flexDirection: "row",
              alignItems: "center",
            }}
          >
            <Text style={{ fontSize: 12, color: "#1D4ED8", fontWeight: "500" }}>
              {worker.employeeId}
            </Text>
          </View>
          <Text style={{ fontSize: 12, color: "#9CA3AF", marginLeft: 10 }}>
            {new Date().toLocaleDateString("en-IN", {
              weekday: "long",
              day: "numeric",
              month: "short",
            })}
          </Text>
        </View>
      </View>

      <ScrollView
        contentContainerStyle={{
          padding: 16,
          paddingBottom: insets.bottom + 80,
        }}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor="#1D4ED8"
          />
        }
      >
        <SyncBadge pendingCount={pendingSync} />

        {/* Today's status */}
        <Text
          style={{
            fontSize: 13,
            fontWeight: "600",
            color: "#6B7280",
            marginBottom: 8,
            textTransform: "uppercase",
            letterSpacing: 0.5,
          }}
        >
          Today's status
        </Text>
        <AttendanceStatusCard record={today} />

        {/* Site */}
        <SiteCard worker={worker} />

        {/* Quick actions */}
        <Text
          style={{
            fontSize: 13,
            fontWeight: "600",
            color: "#6B7280",
            marginTop: 4,
            marginBottom: 10,
            textTransform: "uppercase",
            letterSpacing: 0.5,
          }}
        >
          Actions
        </Text>
        <View style={{ flexDirection: "row", gap: 10, marginBottom: 20 }}>
          <QuickAction
            icon="📍"
            label="Check in"
            sublabel={
              statusConfig.canCheckIn
                ? "Tap to mark attendance"
                : "Already checked in"
            }
            onPress={handleCheckIn}
            variant="primary"
            disabled={!statusConfig.canCheckIn}
          />
          <QuickAction
            icon="🚪"
            label="Check out"
            sublabel={statusConfig.canCheckOut ? "End your shift" : undefined}
            onPress={handleCheckOut}
            variant="danger"
            disabled={!statusConfig.canCheckOut}
          />
        </View>

        {/* Secondary actions */}
        <View style={{ flexDirection: "row", gap: 10, marginBottom: 24 }}>
          <QuickAction
            icon="📋"
            label="History"
            onPress={() => router.push("/(tabs)/history")}
          />
          <QuickAction
            icon="👤"
            label="Profile"
            onPress={() => router.push("/(tabs)/profile")}
          />
        </View>

        {/* Monthly summary */}
        <Text
          style={{
            fontSize: 13,
            fontWeight: "600",
            color: "#6B7280",
            marginBottom: 10,
            textTransform: "uppercase",
            letterSpacing: 0.5,
          }}
        >
          Monthly summary
        </Text>
        <View
          style={{
            backgroundColor: "#FFFFFF",
            borderRadius: 16,
            padding: 16,
            borderWidth: 1,
            borderColor: "#F3F4F6",
          }}
        >
          <SummaryRow summary={summary} />
        </View>

        {/* Last sync */}
        <Text
          style={{
            textAlign: "center",
            fontSize: 11,
            color: "#9CA3AF",
            marginTop: 16,
          }}
        >
          Last synced{" "}
          {new Date().toLocaleTimeString("en-IN", {
            hour: "2-digit",
            minute: "2-digit",
          })}
        </Text>
      </ScrollView>
    </View>
  );
}
