import { Text, View } from "react-native";

export default function HistoryScreen() {
  return (
    <View className="flex-1 items-center justify-center">
      <Text>History Screen</Text>
    </View>
  );
}
