import { Text, View } from "react-native";

export default function AttendanceScreen() {
  return (
    <View className="flex-1 items-center justify-center">
      <Text>Attendance Screen</Text>
    </View>
  );
}
