// import { zodResolver } from "@hookform/resolvers/zod";
// import { router } from "expo-router";
// import { Controller, useForm } from "react-hook-form";

// import {
//     KeyboardAvoidingView,
//     Platform,
//     SafeAreaView,
//     Text,
//     TextInput,
//     TouchableOpacity,
//     View,
// } from "react-native";

// import { signInSchema } from "@/schemas/validation.schemas";
// import { z } from "zod";

// type FormValues = z.infer<typeof signInSchema>;

// export default function SignInScreen() {
//   const {
//     control,
//     handleSubmit,
//     formState: { errors },
//   } = useForm<FormValues>({
//     resolver: zodResolver(signInSchema),
//     defaultValues: {
//       identifier: "",
//       password: "",
//     },
//   });

//   const onSubmit = (data: FormValues) => {
//     console.log(data);

//     router.replace("/(tabs)");
//   };

//   return (
//     <SafeAreaView className="flex-1 bg-white">
//       <KeyboardAvoidingView
//         className="flex-1 px-6"
//         behavior={Platform.OS === "ios" ? "padding" : undefined}
//       >
//         <View className="flex-1 justify-center">
//           <Text className="text-4xl font-bold text-blue-700">PresenceIQ</Text>

//           <Text className="mt-2 text-gray-500">
//             Construction Attendance Tracking
//           </Text>

//           {/* Employee ID */}
//           <View className="mt-10">
//             <Text className="mb-2 text-gray-700">Employee ID / Mobile</Text>

//             <Controller
//               control={control}
//               name="identifier"
//               render={({ field: { value, onChange } }) => (
//                 <TextInput
//                   value={value}
//                   onChangeText={onChange}
//                   placeholder="EMP001"
//                   className="rounded-xl border border-gray-300 p-4"
//                 />
//               )}
//             />

//             {errors.identifier && (
//               <Text className="mt-1 text-red-500">
//                 {errors.identifier.message}
//               </Text>
//             )}
//           </View>

//           {/* Password */}

//           <View className="mt-5">
//             <Text className="mb-2 text-gray-700">Password</Text>

//             <Controller
//               control={control}
//               name="password"
//               render={({ field: { value, onChange } }) => (
//                 <TextInput
//                   secureTextEntry
//                   value={value}
//                   onChangeText={onChange}
//                   placeholder="********"
//                   className="rounded-xl border border-gray-300 p-4"
//                 />
//               )}
//             />

//             {errors.password && (
//               <Text className="mt-1 text-red-500">
//                 {errors.password.message}
//               </Text>
//             )}
//           </View>

//           <TouchableOpacity
//             onPress={handleSubmit(onSubmit)}
//             className="mt-8 rounded-xl bg-blue-700 p-4"
//           >
//             <Text className="text-center font-semibold text-white">
//               Sign In
//             </Text>
//           </TouchableOpacity>
//         </View>
//       </KeyboardAvoidingView>
//     </SafeAreaView>
//   );
// }

// src/app/(auth)/sign-in.tsx

import { router } from "expo-router";
import { Pressable, Text, View } from "react-native";

export default function SignInScreen() {
  return (
    <View className="flex-1 items-center justify-center bg-white px-6">
      <Text className="mb-10 text-3xl font-bold">Sign In</Text>

      <Pressable
        className="rounded-xl bg-blue-600 px-8 py-4"
        onPress={() => {
          router.replace("/(onboarding)/permissions");
        }}
      >
        <Text className="text-white">Demo Login</Text>
      </Pressable>
    </View>
  );
}
