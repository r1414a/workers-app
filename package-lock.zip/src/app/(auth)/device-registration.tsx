// app/(onboarding)/device-registration.tsx

import { router } from "expo-router";

import { Pressable, Text, View } from "react-native";

export default function DeviceRegistrationScreen() {
  const registerDevice = async () => {
    // next phase

    router.replace("/(tabs)");
  };

  return (
    <View className="flex-1 bg-white p-6">
      <Text className="mt-10 text-3xl font-bold">Device Registration</Text>

      <Text className="mt-3 text-gray-500">
        Bind this phone to worker account.
      </Text>

      <Pressable
        onPress={registerDevice}
        className="mt-10 h-14 items-center justify-center rounded-xl bg-blue-600"
      >
        <Text className="font-semibold text-white">Register Device</Text>
      </Pressable>
    </View>
  );
}
