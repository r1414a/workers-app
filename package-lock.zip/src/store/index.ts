import { configureStore } from "@reduxjs/toolkit";

import attendanceReducer from "@/store/slice/attendanceSlice";
import authReducer from "@/store/slice/authSlice";

export const store = configureStore({
  reducer: {
    auth: authReducer,
    attendance: attendanceReducer,
  },
});

export type RootState = ReturnType<typeof store.getState>;

export type AppDispatch = typeof store.dispatch;
