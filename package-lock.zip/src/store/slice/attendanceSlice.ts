import { createSlice } from "@reduxjs/toolkit";

const attendanceSlice = createSlice({
  name: "attendance",

  initialState: {
    todayRecord: null,
    selfieUri: null,
    checkInStep: 1,
  },

  reducers: {
    setTodayRecord(state, action) {
      state.todayRecord = action.payload;
    },

    setSelfie(state, action) {
      state.selfieUri = action.payload;
    },
  },
});

export const { setTodayRecord, setSelfie } = attendanceSlice.actions;

export default attendanceSlice.reducer;
