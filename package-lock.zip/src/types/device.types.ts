export interface DeviceFingerprint {
  androidId: string;
  imei: string | null;
  iccid: string | null;
  model: string;
  osVersion: string;
  appVersion: string;
  fingerprintHash: string; // SHA-256 of above
}

export interface DeviceBindingStatus {
  isRegistered: boolean;
  isCurrentDevice: boolean;
  registeredAt: string | null;
  mismatchReason: string | null;
}
