export type AttendanceStatus = "checked_in" | "checked_out" | "absent" | "late";

export interface AttendanceRecord {
  id: string;
  workerId: string;
  siteId: string;
  siteName: string;
  checkInTime: string;
  checkOutTime: string | null;
  checkInGps: GpsCoords;
  checkOutGps: GpsCoords | null;
  checkInSelfiePath: string;
  checkOutSelfiePath: string | null;
  faceMatchScore: number | null;
  isMockLocation: boolean;
  deviceHash: string;
  status: AttendanceStatus;
  syncStatus: "synced" | "pending" | "failed";
}

export interface GpsCoords {
  latitude: number;
  longitude: number;
  accuracy: number;
  timestamp: number;
}
